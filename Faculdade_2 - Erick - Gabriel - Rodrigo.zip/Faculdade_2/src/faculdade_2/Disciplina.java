/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package faculdade_2;

import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author 182310022
 */
public class Disciplina {
    private int idDisciplina;

    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }
    private String nome, duracao, modalidade;

    public Disciplina(String nome, String duracao, String modalidade) {
        this.nome = nome;
        this.duracao = duracao;
        this.modalidade = modalidade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDuracao() {
        return duracao;
    }

    public void setDuracao(String duracao) {
        this.duracao = duracao;
    }

    public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }
    
     public void cadastrar(){
        String sql =  "INSERT INTO professor (nome, duracao, modalidade) VALUES ( "
                    + " '" + this.getNome() +   "' ,  "
                    + " '" + this.getDuracao() +  "' ,  "
                    + " ' " + this.getModalidade() +" ' ) ";
        Conexao.executar( sql );
    }
    
    public void editar(){
        String sql =  "UPDATE disciplina SET  "
                    + " nome    = '" + this.getNome() +   "' ,  "
                    + " duracao   = '" + this.getDuracao() +  "' ,  "
                    + " modalidade =  '" + this.getModalidade() +" '    "
                    + " WHERE idDisciplina = " + this.getIdDisciplina();
        Conexao.executar( sql );
    }
    
    public static void excluir(int idDisciplina){
        String sql =  "DELETE FROM disciplina WHERE idDisciplina = " + idDisciplina;
        Conexao.executar( sql );
    }
    
    
    public static ArrayList<Disciplina> getDisciplina(){
        ArrayList<Disciplina> lista = new ArrayList<>();
        
        String sql = "SELECT idDisciplina, nome, duracao, modalidade FROM disciplina ORDER BY nome ";
        
        ResultSet rs = Conexao.consultar( sql );
        
        if( rs != null){
            
            try{
                while ( rs.next() ) {                
                    String nome = rs.getString( 2 );
                    String duracao = rs.getString( "duracao" );
                    String modalidade = rs.getString( "modalidade" );
                    
                    Disciplina disciplina = new Disciplina(nome, duracao, modalidade);
                    disciplina.setIdDisciplina( rs.getInt( "idDisciplina" ) );
                    lista.add( disciplina );
                }
            }catch(Exception e){
                
            }
            
        }
     
        return lista;
    }
}
