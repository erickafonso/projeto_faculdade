/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package faculdade_2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author 182310022
 */
public class Faculdade_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ler = new Scanner(System.in);
            ArrayList<Professor> listaProfessores = new ArrayList();
            ArrayList <Aluno> listaAlunos = new ArrayList();
            ArrayList <Contato> listaContato = new ArrayList();
            ArrayList <Curso> listaCurso = new ArrayList();
            ArrayList <Equipamentos> listaEquip = new ArrayList();
            ArrayList <Sala> listaSala = new ArrayList();
            ArrayList <Disciplina> listaDisciplina = new ArrayList();

            int menu, idProf, idAl;
            String nome, email, matricula;
            double salario;
            Professor professor;
            
            do
            {

                System.out.println("Escolha uma opção abaixo:\n1 - Cadastro\n2 - Listar\n3 - Excluir\n4 - 'Editar\n0 - Sair");
                menu=ler.nextInt();

                if (menu == 1)
                {
                System.out.println("1 - Cadastrar Sala");
                System.out.println("2 - Cadastrar Curso");
                System.out.println("3 - Cadastrar Aluno");
                System.out.println("4 - Cadastrar Contato");
                System.out.println("5 - Cadastrar Professor");
                System.out.println("6 - Cadastrar Disciplina");
                System.out.println("7 - Cadastrar Equipamentos");

                menu = ler.nextInt();
                switch (menu)
                    {
                        case 1:
                        System.out.println("Capacidade: ");
                        ler.nextLine();
                        String capacidade = ler.nextLine();
                        System.out.println("Andar: ");
                        String andar = ler.nextLine();
                        System.out.println("Tipo: ");
                        String tipo = ler.nextLine();
                        Sala sala = new Sala(capacidade, andar, tipo);
                        sala.cadastrar();
                        listaSala.add(sala);
                        System.out.println("Cadastrado com sucesso!");
                        break;

                        case 2:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Duração: ");
                        String duracao = ler.nextLine();
                        System.out.println("Valor: ");
                        double valor = ler.nextDouble();
                        Curso curso = new Curso (nome, duracao, valor);
                        curso.cadastrar();
                        listaCurso.add(curso);
                        System.out.println("Cadastrado com sucesso!");
                        break;
                        
                        case 3:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Email: ");
                        email = ler.nextLine();
                        System.out.println("Cpf: ");
                        String cpf = ler.nextLine();
                        System.out.println("Data de Entrada: ");
                        String dataEntrada = ler.nextLine();
                        Aluno aluno = new Aluno(nome, email, cpf, dataEntrada);
                        aluno.cadastrar();
                        listaAlunos.add(aluno);
                        System.out.println("Cadastrado com sucesso!");
                        break;

                        case 4:
                        System.out.println("DDD: ");
                        ler.nextLine();
                        String ddd = ler.nextLine();
                        System.out.println("Número: ");
                        String numero = ler.nextLine();
                        Contato contato = new Contato(ddd, numero);
                        contato.cadastrar();
                        listaContato.add(contato);
                        System.out.println("Cadastrado com sucesso!");
                        break;

                        case 5:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Email: ");
                        email = ler.nextLine();
                        System.out.println("Salário: ");
                        salario = ler.nextDouble();
                        professor = new Professor(nome, email, salario);
                        professor.cadastrar();
                        listaProfessores.add(professor);
                        System.out.println("Cadastrado com sucesso!");
                        break;

                        case 6:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Duração: ");
                        duracao = ler.nextLine();
                        System.out.println("Modalidade: ");
                        String modalidade = ler.nextLine();
                        Disciplina disciplina = new Disciplina(nome, duracao, modalidade);
                        disciplina.cadastrar();
                        listaDisciplina.add(disciplina);
                        System.out.println("Cadastrado com sucesso!");
                        break;

                        case 7:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        Equipamentos equipamento = new Equipamentos(nome);
                        equipamento.cadastrar();
                        listaEquip.add(equipamento);
                        System.out.println("Cadastrado com sucesso!");
                        break;
                    }

                    if (menu == 2)
                    {
                        System.out.println("1 - Listar Sala");
                        System.out.println("2 - Listar Curso");
                        System.out.println("3 - Listar Aluno");
                        System.out.println("4 - Listar Contato");
                        System.out.println("5 - Listar Professor");
                        System.out.println("6 - Listar Disciplina");
                        System.out.println("7 - Listar Equipamentos");

                        switch (menu)
                        {
                            case 1:
                            System.out.println("Lista de Salas: ");
                            listaSala = Sala.getSala();
                            for(Sala s:listaSala)
                            {
                                s.dados();
                            }
                            break;

                            case 2:
                            System.out.println("Lista de Cursos: ");
                            listaCurso = Curso.getCurso();
                            for(Curso c:listaCurso)
                            {
                                c.dados();
                            }
                            break;

                            case 3:
                            System.out.println("Lista de Alunos:\n ");
                            listaAlunos = Aluno.getAluno();
                            for(Aluno a:listaAlunos)
                            {
                                a.dados();
                            }
                            break;

                            case 4:
                            System.out.println("Lista de Contatos: ");
                            listaContato = Contato.getContato();
                            for(Contato co:listaContato)
                            {
                                co.dados();
                            }
                            break;

                            case 5:
                            System.out.println("Lista de Professores: ");
                            listaProfessores = Professor.getProfessores();
                            for(Professor p:listaProfessores)
                            {
                                p.dados();
                            }
                            break;

                            case 6:
                            System.out.println("Lista de Disciplinas: ");
                            listaDisciplina = Disciplina.getDisciplinas();
                            for(Disciplina d:listaDisciplina)
                            {
                                d.dados();
                            }
                            break;

                            case 7:
                            System.out.println("Lista de Equipamentos: ");
                            listaEquip = Equipamentos.getEquipamentos();
                            for(Equipamentos e:listaEquip)
                            {
                                e.dados();
                            }
                            break;
                        }
                    }

                    if (menu == 3)
                    {
                        System.out.println("1 - Excluir Sala");
                        System.out.println("2 - Excluir Curso");
                        System.out.println("3 - Excluir Aluno");
                        System.out.println("4 - Excluir Contato");
                        System.out.println("5 - Excluir Professor");
                        System.out.println("6 - Excluir Disciplina");
                        System.out.println("7 - Excluir Equipamentos");

                        switch (menu)
                        {
                            case 1:
                            listaSala = Sala.getSala();
                            for(Sala s:listaSala)
                            {
                             //   System.out.println( s.getId() + "  -  " + s.getNome() );
                                System.out.println( s.getId() + "  -  " );
                            }
                            
                            System.out.print("Digite o ID da Sala que será excluída: ");
                            int idSala = ler.nextInt();
                            Sala.excluir( idSala );
                            break;

                            case 2:
                            listaCurso = Curso.getCurso();
                            for(Curso c:listaCurso)
                            {
                                System.out.println( c.getIdCurso() + "  -  " + c.getNome() );
                            }
                            
                            System.out.print("Digite o ID do Curso que será excluído: ");
                            int idCurso = ler.nextInt();
                            Curso.excluir( idCurso );
                            break;

                            case 3:
                            listaAlunos = Aluno.getAluno();
                            for(Aluno a:listaAlunos)
                            {
                                System.out.println( a.getId() + "  -  " + a.getNome() );
                            }                            
                            System.out.print("Digite o ID do Aluno que será excluído: ");
                            idAl = ler.nextInt();
                            Aluno.excluir( idAl );
                            break;

                            case 4:
                            listaContato = Contato.getContato();
                            for(Contato co:listaContato)
                            {
                                System.out.println( co.getIdTelefone() + "  -  " + co.getNumero() );
                            }
                            
                            System.out.print("Digite o ID do Contato que será excluído: ");
                            int idContato = ler.nextInt();
                            Contato.excluir( idContato );
                            break;

                            case 5:
                            listaProfessores = Professor.getProfessores();
                            for(Professor p:listaProfessores)
                            {
                                System.out.println( p.getId() + "  -  " + p.getNome() );
                            }
                            
                            System.out.print("Digite o ID do professor que será excluído: ");
                            idProf = ler.nextInt();
                            Professor.excluir( idProf );
                            break;

                            case 6:
                            listaDisciplina = Disciplina.getDisciplina();
                            for(Disciplina d:listaDisciplina)
                            {
                                System.out.println( d.getidDisciplina() + "  -  " + d.getNome() );
                            }
                            
                            System.out.print("Digite o ID do Aluno que será excluído: ");
                            int idDisciplina = ler.nextInt();
                            Disciplina.excluir( idDisciplina );
                            break;

                            case 7:
                            listaEquip = Equipamentos.getEquipamentos();
                            for(Equipamentos e:listaEquip)
                            {
                                System.out.println( e.getId() + "  -  " + e.getNome() );
                            }
                            
                            System.out.print("Digite o ID do Equipamento que será excluído: ");
                            int idEquip = ler.nextInt();
                            Equipamentos.excluir( idEquip );
                            break;
                        
                    
        }while(menu!=9);
    }
    
}
