package faculdade_2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author fltreib
 */
public class Faculdade 
{
        public static void main(String[] args) 
        {
        Scanner ler = new Scanner(System.in);
            ArrayList<Professor> listaProfessores = new ArrayList();
            ArrayList <Aluno> listaAlunos = new ArrayList();
            ArrayList <Contato> listaContato = new ArrayList();
            ArrayList <Curso> listaCurso = new ArrayList();
            ArrayList <Equipamentos> listaEquip = new ArrayList();
            ArrayList <Sala> listaSala = new ArrayList();
            ArrayList <Disciplina> listaDisciplina = new ArrayList();

            int menu, idProf, idAl;
            String nome, email, matricula;
            double salario;
            Professor professor;
            
            do
            {

                System.out.println("Escolha uma opção abaixo:\n1 - Cadastro\n2 - Listar\n3 - Excluir\n4 - 'Editar\n0 - Sair");
                menu=ler.nextInt();

                if (menu == 1)
                {
                System.out.println("1 - Cadastrar Sala");
                System.out.println("2 - Cadastrar Curso");
                System.out.println("3 - Cadastrar Aluno");
                System.out.println("4 - Cadastrar Contato");
                System.out.println("5 - Cadastrar Professor");
                System.out.println("6 - Cadastrar Disciplina");
                System.out.println("7 - Cadastrar Equipamentos");

                menu = ler.nextInt();
                switch (menu)
                    {
                        case 1:
                        System.out.println("Capacidade: ");
                        ler.nextLine();
                        String capacidade = ler.nextLine();
                        System.out.println("Andar: ");
                        String andar = ler.nextLine();
                        System.out.println("Tipo: ");
                        String tipo = ler.next();
                        Sala sala = new Sala(capacidade, andar, tipo);
                        sala.cadastrar();
                        System.out.println("estou aqui");
                        listaSala.add(sala);
                        System.out.println("Cadastrado com sucesso!");
                        break;

                        case 2:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Duração: ");
                        String duracao = ler.nextLine();
                        System.out.println("Valor: ");
                        double valor = ler.nextDouble();
                        Curso curso = new Curso (nome, duracao, valor);
                        curso.cadastrar();
                        listaCurso.add(curso);
                        System.out.println("Cadastrado com sucesso!");
                        break;
                        
                        case 3:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Email: ");
                        email = ler.nextLine();
                        System.out.println("Cpf: ");
                        String cpf = ler.nextLine();
                        System.out.println("Data de Entrada: ");
                        String dataEntrada = ler.nextLine();
                        Aluno aluno = new Aluno(nome, email, cpf, dataEntrada);
                        aluno.cadastrar();
                        listaAlunos.add(aluno);
                        System.out.println("Cadastrado com sucesso!");
                        break;

                        case 4:
                        System.out.println("DDD: ");
                        ler.nextLine();
                        String ddd = ler.nextLine();
                        System.out.println("Número: ");
                        String numero = ler.nextLine();
                        Contato contato = new Contato(ddd, numero);
                        contato.cadastrar();
                        listaContato.add(contato);
                        System.out.println("Cadastrado com sucesso!");
                        break;

                        case 5:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Email: ");
                        email = ler.nextLine();
                        System.out.println("Salário: ");
                        salario = ler.nextDouble();
                        professor = new Professor(nome, email, salario);
                        professor.cadastrar();
                        listaProfessores.add(professor);
                        System.out.println("Cadastrado com sucesso!");
                        break;

                        case 6:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Duração: ");
                        duracao = ler.nextLine();
                        System.out.println("Modalidade: ");
                        String modalidade = ler.nextLine();
                        Disciplina disciplina = new Disciplina(nome, duracao, modalidade);
                        disciplina.cadastrar();
                        listaDisciplina.add(disciplina);
                        System.out.println("Cadastrado com sucesso!");
                        break;

/*                        case 7:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Email: ");
                        email = ler.nextLine();
                        System.out.println("Salário: ");
                        salario = ler.nextDouble();
                        professor = new Professor(nome, email, salario);
                        professor.cadastrar();
                        listaProfessores.add(professor);
                        System.out.println("Cadastrado com sucesso!");
                        break;
                    }
                    break;

                
                System.out.println("8 - Listar Sala");
                System.out.println("9 - Listar Curso");
                System.out.println("10 - Listar Aluno");
                System.out.println("11 - Listar Contato");
                System.out.println("12 - Listar Professor");
                System.out.println("13 - Listar Disciplina");
                System.out.println("14 - Listar Equipamentos");
                System.out.println("15 - Excluir Sala");
                System.out.println("16 - Excluir Curso");
                System.out.println("17 - Excluir Aluno");
                System.out.println("18 - Excluir Contato");
                System.out.println("19 - Excluir Professor");
                System.out.println("20 - Excluir Disciplina");
                System.out.println("21 - Excluir Equipamentos");
                System.out.println("15 - Editar Sala");
                System.out.println("16 - Editar Curso");
                System.out.println("17 - Editar Aluno");
                System.out.println("18 - Editar Contato");
                System.out.println("19 - Editar Professor");
                System.out.println("20 - Editar Disciplina");
                System.out.println("21 - Editar Equipamentos");
                
                System.out.println("7 - Editar Professor");
                System.out.println("8 - Editar Aluno");
                System.out.println("9 - Sair");
                System.out.print("Digite sua opção: ");
                menu=ler.nextInt();
                switch(menu)
                {
                    case 1:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Email: ");
                        email = ler.nextLine();
                        System.out.println("Salário: ");
                        salario = ler.nextDouble();
                        professor = new Professor(nome, email, salario);
                        professor.cadastrar();
                        listaProfessores.add(professor);
                        System.out.println("Cadastrado com sucesso!");
                    break;
                    
                    case 2:
                        System.out.println("Nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Email: ");
                        email = ler.nextLine();
                        System.out.println("Matrícula: ");
                        matricula = ler.nextLine();
                        Aluno aluno = new Aluno(nome, email, matricula);
                        aluno.cadastrar();
                        listaAlunos.add(aluno);
                        System.out.println("Cadastrado com sucesso!");
                    break;
                    
                    case 3:
                        System.out.println("Lista de Professores: ");
                        listaProfessores = Professor.getProfessores();
                        for(Professor p:listaProfessores)
                        {
                            p.dados();
                        }
                    break;
                    
                    case 4:
                        System.out.println("Lista de Alunos:\n ");
                        listaAlunos = Aluno.getAlunos();
                        for(Aluno a:listaAlunos)
                        {
                            a.dados();
                        }
                    break;
                    
                    case 5:
                        listaProfessores = Professor.getProfessores();
                        for(Professor p:listaProfessores)
                        {
                            System.out.println( p.getId() + "  -  " + p.getNome() );
                        }
                        
                        System.out.print("Digite o ID do professor que será excluído: ");
                        idProf = ler.nextInt();
                        Professor.excluir( idProf );
                    break;
                    
                    case 6:
                        listaAlunos = Aluno.getAlunos();
                        for(Aluno a:listaAlunos)
                        {
                            System.out.println( a.getId() + "  -  " + a.getNome() );
                        }
                        
                        System.out.print("Digite o ID do Aluno que será excluído: ");
                        idAl = ler.nextInt();
                        Aluno.excluir( idAl );
                    break;
                    
                    case 7:
                        listaProfessores = Professor.getProfessores();
                        for(Professor p:listaProfessores)
                        {
                            System.out.println( p.getId() + "  -  " + p.getNome() );
                        }
                        System.out.print("Digite o ID do professor que será editado: ");
                        idProf = ler.nextInt();
                        System.out.println("Novo nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Novo e-mail: ");
                        email = ler.nextLine();
                        System.out.println("Novo salário: ");
                        salario = ler.nextDouble();
                        professor = new Professor(nome, email, salario);
                        professor.setId( idProf );
                        professor.editar();
                    break;
                    
                    case 8:
                        listaAlunos = Aluno.getAlunos();
                        for(Aluno a:listaAlunos)
                        {
                            System.out.println( a.getId() + "  -  " + a.getNome() );
                        }
                        System.out.print("Digite o ID do Aluno que será editado: ");
                        idAl = ler.nextInt();
                        System.out.println("Novo nome: ");
                        ler.nextLine();
                        nome = ler.nextLine();
                        System.out.println("Novo e-mail: ");
                        email = ler.nextLine();
                        System.out.println("Matrícula: ");
                        matricula = ler.nextLine();
                        aluno = new Aluno(nome, email, matricula);
                        aluno.setId( idAl );
                        aluno.editar();
                    break;*/
                }
                }
        }while(menu!=9);
    } 
}
