
package dao;

/**
 *
 * @author cralves
 */
public class DAOFactory {
    //Instanciando o objeto a classe ProdutoDAO
    private static ProdutoDAO produtoDAO = new ProdutoDAO();
    
    //Fazendo uma cópia dos métodos da classe ProdutoDAO e 
    //disponibilizar para a classe que solicitar
    public static ProdutoDAO getProdutoDAO(){
        return produtoDAO;
    }//fim do método getProdutoDAO
    
    //Instanciando o objeto a classe ClientesDAO
    private static ClientesDAO clientesDAO = new ClientesDAO();
    
    //Fazendo uma cópia dos métodos da classe ClientesDAO e 
    //disponibilizar para a classe que solicitar
    public static ClientesDAO getClientesDAO(){
        return clientesDAO;
    }//fim do método ClientesDAO
}//fecha a classe DAOFactory
