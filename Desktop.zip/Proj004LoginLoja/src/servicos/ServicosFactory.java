
package servicos;

/**
 *
 * @author cralves
 */
public class ServicosFactory {
    private static ProdutoServicos produtoServicos = new ProdutoServicos();
    

    public static ProdutoServicos getProdutoServicos(){
        return produtoServicos;
    }//fim do método getProdutoServicos
    
private static ClientesServicos clientesServicos = new ClientesServicos();
      
    
    public static ClientesServicos getClientesSevicos(){
        return clientesServicos;
    }//fim do método getClientesServicos
    
}//fecha a classe ServicosFactory
