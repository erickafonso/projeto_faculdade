/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.ClientesVO;
import persistencia.ConexaoBanco;

/**
 *
 * @author cralves
 */
public class ClientesDAO {
    private Connection con;
    
//Método Construtor
public ClientesDAO(){
    this.con = new ConexaoBanco().getConexao();
} //fim do método construtor   
    
    public void cadastrarClientes(ClientesVO cVO){
        
        try {
            //1º criar SQL
            String sql = "insert into clientes values(null, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
            
            //2º preparar a conexão SQL para se conectar com o banco
            PreparedStatement pstm = con.prepareStatement(sql);
            
            pstm.setString(1, cVO.getNome());
            pstm.setString(2, cVO.getEmail());
            pstm.setString(3, cVO.getFone());
            pstm.setString(4, cVO.getCpf());
            pstm.setString(5, cVO.getLogradouro());
            pstm.setString(6, cVO.getNumero());
            pstm.setString(7, cVO.getComplemento());
            pstm.setString(8, cVO.getBairro());
            pstm.setString(9, cVO.getCep());
            pstm.setString(10, cVO.getCidade());
            pstm.setString(11, cVO.getUf());
            
            //3º executar o SQL
            pstm.execute();
            //4º fechar a conexão
            pstm.close();
            //5º informar ao usuário
            JOptionPane.showMessageDialog(
                    null,
                    "Cliente cadastrado com sucesso!");
        } catch (SQLException se) {
            JOptionPane.showMessageDialog(
                    null,
                    "Erro ao cadastrar cliente! " + se);
        }
                
    }//fim do método cadastrarClientes
    
    
    public ClientesVO buscarClientes(String nome){
        try {
            String sql = "select * from clientes where nome =?";
            PreparedStatement pstm = con.prepareStatement(sql);
            pstm.setString(1, nome);
            
            ResultSet rs = pstm.executeQuery();
            
            ClientesVO cVO = new ClientesVO();
            if(rs.next()){
                cVO.setCodigo(rs.getInt("idClientes"));
                cVO.setNome(rs.getString("nome"));
                cVO.setEmail(rs.getString("email"));
                cVO.setFone(rs.getString("fone"));
                cVO.setCpf(rs.getString("cpf"));
                cVO.setLogradouro(rs.getString("logradouro"));
                cVO.setNumero(rs.getString("numero"));
                cVO.setComplemento(rs.getString("complemento"));
                cVO.setBairro(rs.getString("bairro"));
                cVO.setCep(rs.getString("cep"));
                cVO.setCidade(rs.getString("cidade"));
                cVO.setUf(rs.getString("uf"));                
            }//fim do if
            pstm.close();
            return cVO;
        } catch (SQLException se) {
            JOptionPane.showMessageDialog(null, 
                    "Erro ao cadastrar Cliente." + se);
        }//fecha o try catch
        return null;
                
    }//fim do método buscarClientes
    
    
    public ArrayList<ClientesVO> listar(){
        ArrayList<ClientesVO> lista = new ArrayList<>();
        try {
            String sql = "Select * from clientes ";
            PreparedStatement pstm = con.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            
            while( rs.next()){
                ClientesVO  cVO = new ClientesVO();
                cVO.setCodigo(rs.getInt("idclientes"));
                cVO.setNome(rs.getString("nome"));
                cVO.setEmail(rs.getString("email"));
                cVO.setFone(rs.getString("fone"));
                cVO.setCpf(rs.getString("cpf"));
                cVO.setLogradouro(rs.getString("logradouro"));
                cVO.setNumero(rs.getString("numero"));
                cVO.setComplemento(rs.getString("complemento"));
                cVO.setBairro(rs.getString("bairro"));
                cVO.setCep(rs.getString("cep"));
                cVO.setCidade(rs.getString("cidade"));
                cVO.setUf(rs.getString("uf"));
                
                lista.add(cVO);
            }//fim do while
            pstm.close();
            return lista;
        } catch (SQLException se) {
            JOptionPane.showMessageDialog(null, "Erro ao criar a lista!" + se);
        }//fim try catch
        return null;
    }//fim do método listar
    
}//fecha a classe ClientesDAO
