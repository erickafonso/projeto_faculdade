/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.formulario;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JPanel;
/**
 *
 * @author erick
 */
public class Formulario extends JFrame {
   // JTextField login;
    public Formulario(){
        Container c = getContentPane();
        c.add(new designForm());
       
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(755,755);
        setVisible(true);
    
    
    }
    public static void main(String[] args) {
        new Formulario();
    }
}
