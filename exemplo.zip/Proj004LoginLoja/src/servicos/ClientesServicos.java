/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servicos;

import dao.ClientesDAO;
import dao.DAOFactory;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.ClientesVO;

/**
 *
 * @author 181700028
 */
public class ClientesServicos {
    public void cadastrarClientes(ClientesVO cVO) throws SQLException {
        ClientesDAO cDAO = DAOFactory.getClientesDAO();
        cDAO.cadastrarClientes(cVO);
    }
    public ArrayList<ClientesVO> buscarClientes() throws SQLException{
        ClientesDAO cDAO = DAOFactory.getClientesDAO();
        return cDAO.buscarClientes();
    }
    
    
    public ArrayList<ClientesVO> pesquisarClientes(String query) throws SQLException{
        ClientesDAO cDAO = DAOFactory.getClientesDAO();
        return cDAO.pesquisarClientes(query);
    }
    
}
