/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import modelo.ClientesVO;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import persistencia.ConexaoBanco;

/**
 *
 * @author 181700028
 */
public class ClientesDAO {
    
    public void cadastrarClientes(ClientesVO cVO) throws SQLException{
        
        Connection con =new ConexaoBanco().getConexao();
        try{
            String sql = "insert into cliente values (null, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstm= con.prepareStatement(sql);
            pstm.setString(1, cVO.getNome());
            pstm.setString(2, cVO.getCPF());
            pstm.setString(3, cVO.getEmail());
            pstm.setString(4, cVO.getFone());
            pstm.setString(5, cVO.getEndereco());
            pstm.setString(6, cVO.getCEP());
            pstm.setString(7, cVO.getBairro());
            pstm.setString(8, cVO.getUf());
            
            pstm.execute();
            pstm.close();
            
        }catch(SQLException se){
            throw new SQLException("Erro ao cadastrar Cliente(DAO)! " + se.getMessage());
        }finally{
            con.close();
        }
        
        
    }
    public ArrayList<ClientesVO> buscarClientes() throws SQLException{
        
        Connection con =new ConexaoBanco().getConexao();
        try{
            String sql= "Select * from cliente";
            PreparedStatement pstm= con.prepareStatement(sql);
            ResultSet rs= pstm.executeQuery();
            ArrayList<ClientesVO> cli =new ArrayList<>();
            
            while(rs.next()){
                ClientesVO cVO=new ClientesVO();
                cVO.setCodCli(rs.getInt("idcliente"));
                cVO.setNome(rs.getString("nome"));
                cVO.setCPF(rs.getString("cpf"));
                cVO.setEmail(rs.getString("email"));
                cVO.setFone(rs.getString("fone"));
                cVO.setEndereco(rs.getString("endereco"));
                cVO.setCEP(rs.getString("cep"));
                cVO.setBairro(rs.getString("bairro"));
                cVO.setUf(rs.getString("uf"));
                
                cli.add(cVO);
                
            }
            
            pstm.close();
            return cli;
            
        }catch(SQLException se){
            throw new SQLException("Erro ao buscar Cliente(DAO)! " + se.getMessage());
        }finally{
            con.close();
        }
        
        
    }
    
    
   public ArrayList<ClientesVO> pesquisarClientes(String query) throws SQLException{
       Connection con = new ConexaoBanco().getConexao();
       
       try {
           String sql = " Select * from cliente " + query;
           PreparedStatement pstm = con.prepareStatement(sql);
           ResultSet rs = pstm.executeQuery();
           ArrayList<ClientesVO> cli = new ArrayList<>();
           ClientesVO cVO = new ClientesVO();
           
           while(rs.next()){
               cVO.setCodCli(rs.getInt("idcliente"));
               cVO.setNome(rs.getString("nome"));
               cVO.setCPF(rs.getString("cpf"));
               cVO.setEmail(rs.getString("email"));
               cVO.setFone(rs.getString("fone"));
               cVO.setEndereco(rs.getString("endereco"));
               cVO.setCEP(rs.getString("cep"));
               cVO.setBairro(rs.getString("bairro"));
               cVO.setUf(rs.getString("uf"));   
             
               cli.add(cVO);
           }//fim do while
           
           pstm.close();
           return cli;
                      
       } catch (SQLException se) {
           throw new SQLException( "Erro ao pesquisar cliente! " + se);
       }finally{
           con.close();
       }//fim do finally
       
   }//fim do método pesquisar
    
    
}
